//
//  AppDelegate.h
//  SignupLoginDemo
//
//  Created by Ashish Sharma on 04/09/14.
//  Copyright (c) 2014 Ashish Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CloobieViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    CloobieViewController *one;
    UINavigationController *two;
}

@property (strong, nonatomic) UIWindow *window;
@property(nonatomic,retain)   CloobieViewController *one;
@property(nonatomic,retain)   UINavigationController *two;

@end
